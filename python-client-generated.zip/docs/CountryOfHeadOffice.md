# CountryOfHeadOffice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**valid_from** | **date** |  | [optional] 
**value** | **str** | Country in which the company has its head office. The following values are permissible (see \&quot;country_of_birth\&quot; definition). | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


