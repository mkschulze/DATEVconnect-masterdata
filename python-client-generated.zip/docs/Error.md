# Error

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**additional_messages** | [**list[AdditionalMessage]**](AdditionalMessage.md) |  | [optional] 
**error** | **str** | error code | 
**error_description** | **str** | Longer error description | [optional] 
**error_uri** | **str** | URI to further information | [optional] 
**request_id** | **str** | ID of the original request | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


