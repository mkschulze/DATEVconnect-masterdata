# EnterprisePurpose

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**valid_from** | **date** |  | [optional] 
**value** | **str** | The activity or the main output that a company produces. The main product line of a company can be derived from the enterprise purpose. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


