# MADCodeOfClassificationOfEconomicActivities2008

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**valid_from** | **date** |  | [optional] 
**value** | **str** | Code of classification of economic activities (2008) with DATEV extensions. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


