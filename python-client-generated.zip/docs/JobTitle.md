# JobTitle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**valid_from** | **date** |  | [optional] 
**value** | **str** | Work or activity in which a natural person is trained and earns a living. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


