# AdditionalMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | id of additional message | 
**description** | **str** | Further information of message | [optional] 
**help_uri** | **str** |  | [optional] 
**severity** | **str** | severity of error | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


